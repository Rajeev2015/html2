import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'


export const Edit = () => {
  const { id } = useParams();
  const navigate = useNavigate()
  const [bookdeatils, setBookdetails] = useState({
    book_name: '',
    book_author: '',
    book_edition: '',
    book_page_number: '',
    book_price: '',
    book_descrition: '',
  })
  const getBookDetailById = async () => {
    const res = await axios.get("http://localhost:3004/book_details/" + id)
    // console.log("book detsils "+res.data);

    setBookdetails(res.data)
  }

  const handler = (e) => {
    const { name, value } = e.target;
    setBookdetails({ ...bookdeatils, [name]: value })

  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.put("http://localhost:3004/book_details/" + id, bookdeatils)
      console.log(res);
      if (res.status === 200) {
        navigate("/book-details") // redirect 
      }

    } catch (err) {
      console.log(err);

    }

  }
  useEffect(() => {
    getBookDetailById();

  }, [])
  return (
    <div className="container">
      <div className="row">
        <div className="col-md-3"></div>
        <div className="col-md-6">
          <div className="container mt-5">
            <div className="card shadow rounded">
              <div className="card-header bg-primary text-white">
                <h4 className="mb-0">
                  <i className="bi bi-pencil-square me-2" />
                  Edit Book Details
                </h4>
              </div>
              
              <div className="card-body">
                <form onSubmit={handleSubmit}>
                  <div className="mb-3">
                    <label htmlFor="book_name" className="form-label">
                      Book Name
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      id="book_name"
                      name='book_name'
                      onChange={handler}
                      value={bookdeatils.book_name}
                    />
                  </div>
                  <div className="mb-3">
                    <label htmlFor="book_author" className="form-label">
                      Author
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      id="book_author"
                      name='book_author'
                      onChange={handler}
                      value={bookdeatils.book_author}
                    />
                  </div>
                  <div className="mb-3">
                    <label htmlFor="book_edition" className="form-label">
                      Edition
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      id="book_edition"
                      name='book_edition'
                      onChange={handler}
                      value={bookdeatils.book_edition}
                    />
                  </div>
                  <div className="mb-3">
                    <label htmlFor="book_page_number" className="form-label">
                      Page Number
                    </label>
                    <input
                      type="number"
                      className="form-control"
                      id="book_page_number"
                      name='book_page_number'
                      onChange={handler}
                      value={bookdeatils.book_page_number}
                    />
                  </div>
                  <div className="mb-3">
                    <label htmlFor="book_price" className="form-label">
                      Price (₹)
                    </label>
                    <input
                      type="number"
                      className="form-control"
                      id="book_price"
                      name='book_price'
                      onChange={handler}
                      value={bookdeatils.book_price}
                    />
                  </div>
                  <div className="mb-3">
                    <label htmlFor="book_description" className="form-label">
                      Description
                    </label>
                    <textarea
                      className="form-control"
                      id="book_description"
                      rows={4}
                      placeholder="Enter book description"
                      defaultValue={""}
                      name='book_descrition'
                      onChange={handler}
                      value={bookdeatils.book_descrition}
                    />
                  </div>
                  <button type="submit" className="btn btn-success">
                    <i className="bi bi-save" /> Update Book
                  </button>
                </form>
              </div>
            </div>
          </div>

        </div>
        <div className="col-md-3"></div>
      </div>
    </div>
  )
}
