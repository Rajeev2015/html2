import axios from 'axios'
import React, { useEffect, useState } from 'react'
import ReactPaginate from 'react-paginate';


export const Pagination = () => {
    const [store, setStore] = useState([])
    const [page, setPage] = useState(1);
    const [total, setTotal] = useState(0);

    const getAllRecords = async () => {
        try {
            const res = await axios.get("https://jsonplaceholder.typicode.com/photos?_page=" + page + "&_limit=4")
            setStore(res.data)
        } catch (err) {
            console.log(err);

        }
    }
    const getAllRecordTotal = async () => {
        try {
            const res = await axios.get("https://jsonplaceholder.typicode.com/photos")
            console.log(res);

            setTotal(res.data.length / 4)
        } catch (err) {
            console.log(err);

        }
    }

    const handlePageClick=(data)=>{
         console.log(data);
          setPage(data.selected + 1);   
    }
    useEffect(() => {
        getAllRecords();
        getAllRecordTotal();
    }, [page])
    return (
        <div className="container">
            <div className="row">
                <div className="col-md-12">
                    <div style={{textTransform:"uppercase",margin:"2% 2%",textAlign:"center",fontSize:"30px"}}>Card Data With Pagination</div>
                </div>
            </div>
            <div className="row">
                {
                    store.map((item, index) =>
                        <div className="col-md-3">
                            <div className="card m-2" style={{ width: "100%" }}>
                                <img src={item.thumbnailUrl} className="card-img-top" style={{height:"120px"}} alt="..." />
                                <div className="card-body">
                                    <h5 className="card-title">{item.id}</h5>
                                    <h5 className="card-title" style={{fontSize:"14px"}}>{item.title.substring(0,45)}</h5>
                                    <p className="card-text">
                                        Some quick example text to  build on the card title and make up the bulk of
                                        the card’s content.
                                    </p>
                                    <a href="#" className="btn btn-primary">
                                        Go somewhere
                                    </a>
                                </div>
                            </div>

                        </div>
                    )
                }
            </div>
               <ReactPaginate 
                        previousLabel={'Previous'}
                        nextLabel= {'Next'}
                        breakLabel={'...'}
                        pageCount={total}
                        marginPagesDisplayed={3}
                        pageRangeDisplayed={6}
                        onPageChange={handlePageClick}
                       containerClassName={'pagination'}
                       pageClassName={'page-item'}
                       pageLinkClassName={'page-link'}
                       previousClassName={'page-item'}
                       previousLinkClassName={'page-link'}
                       nextClassName={'page-item'}
                       nextLinkClassName={'page-link'}
                       breakClassName={'page-item'}
                       breakLinkClassName={'page-link'}
                       activeClassName={'active'}
                    />

        </div>
    )
}
