import axios from 'axios'
import React, { Component } from 'react'

export default class Contact extends Component {
  constructor()
  {
    super()
    this.state={
      f_name:'',
      l_name:'',
      email_id:'',
      mobile_number:'',
      message:'',
      msg:''
    }
  }
  setFname=(event)=>{
    // console.log(event);
    // console.log(event.target);
    // console.log(event.target.value);
    this.setState({f_name:event.target.value})
  }

  setLname=(e)=>{
    //  console.log(e.target);
    // console.log(e.target.value);
    this.setState({l_name:e.target.value})
  }
  setEmail=(e)=>{
    this.setState({email_id:e.target.value})
  }
   setMobile=(e)=>{
    this.setState({mobile_number:e.target.value})
  }
   setMessage=(e)=>{
    this.setState({message:e.target.value})
  }

  handleSubmit=(e)=>{
    e.preventDefault();
    // console.log(this.state);
    axios.post("http://localhost:3004/contact",this.state)
    .then((response)=>{
      // console.log(response);
      if(response.status===200 || response.status===201)
      {
        this.setState({msg:"Message Send Successfully !"})
      }
      
    })
    
  }
  render() {
    return (
      <>
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <div className="my_title">
                Contact form
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-md-3"></div>
            <div className="col-md-6">
              {
                this.state.msg?(
                  <div className='alert alert-success'>{this.state.msg}</div>
                ):''
              }
              <form action="" method='post' onSubmit={this.handleSubmit}>
                <div className="row">
                  <div className="col">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="First name"
                      aria-label="First name"
                      name="f_name"
                      onChange={this.setFname}
                    />
                  </div>
                  <div className="col">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Last name"
                      aria-label="Last name"
                       name="l_name"
                      onChange={this.setLname}
                    />
                  </div>
                </div>
                <div className="row" style={{ marginTop: "2%" }}>
                  <div className="col">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Email Id"
                      aria-label="First name"
                       name="email_id"
                      onChange={this.setEmail}
                    />
                  </div>
                  <div className="col">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Mobile Number"
                      aria-label="Last name"
                       name="f_name"
                      onChange={this.setMobile}
                    />
                  </div>
                </div>
                <div className="row" style={{ marginTop: "2%" }}>
                  <div className="col">
                    <textarea  name="f_name"
                      onChange={this.setMessage} style={{ height: "90px" }} className='form-control' id="" placeholder='Enter Message'></textarea>
                  </div>

                </div>
                <div className="row" style={{ marginTop: "2%" }}>
                  <div className="col">
                    <input type="submit" value="Send Message" className='btn btn-primary' />
                  </div>

                </div>

              </form>
            </div>
            <div className="col-md-3"></div>
          </div>
        </div>
      </>
    )
  }
}
