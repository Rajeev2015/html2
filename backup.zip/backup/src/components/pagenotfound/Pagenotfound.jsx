import React, { Component } from 'react'

export default class Pagenotfound extends Component {
  render() {
    return (
      <div className='my_title'>Pagenotfound</div>
    )
  }
}
