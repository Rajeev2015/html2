import React, { Component } from 'react'

export default class Footer extends Component {
  render() {
    return (
      <div style={{marginTop:"5%",height:"300px",backgroundColor:"darkblue"}}>Footer</div>
    )
  }
}
