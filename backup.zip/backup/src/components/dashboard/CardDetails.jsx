import React, { Component } from 'react'

export default class CardDetails extends Component {
    constructor() {
        super();
        this.state = [
            {
                p_title: 'Shirt',
                p_desc: "Ver Good",
                p_img: "gallery/61.jpg"
            },
            {
                p_title: 'Shirt',
                p_desc: "Ver Good",
                p_img: "gallery/65.jpg"
            },
            {
                p_title: 'Shirt',
                p_desc: "Ver Good",
                p_img: "gallery/77.jpg"
            },
            {
                p_title: 'Shirt',
                p_desc: "Ver Good",
                p_img: "gallery/85.jpg"
            },
            {
                p_title: 'Shirt',
                p_desc: "Ver Good",
                p_img: "gallery/89.jpg"
            },
            {
                p_title: 'Shirt',
                p_desc: "Ver Good",
                p_img: "gallery/113.jpg"
            },
            {
                p_title: 'Shirt',
                p_desc: "Ver Good",
                p_img: "gallery/77.jpg"
            },
            {
                p_title: 'Shirt',
                p_desc: "Ver Good",
                p_img: "gallery/85.jpg"
            }
        ]
    }
    render() {
        return (
            <>
                <div className="container">
                    <div className="row">
                        {
                            this.state.map((item, index) =>
                              <div className="col-md-3" key={index}>
                                  <div className="card m-2" style={{ width: "100%" }}>
                                    <img src={item.p_img} className="card-img-top my_img" alt="..." />
                                    <div className="card-body">
                                        <h5 className="card-title">{item.p_title}</h5>
                                        <p className="card-text">
                                           {item.p_desc}
                                        </p>
                                        <a href="#" className="btn btn-primary">
                                            Go somewhere
                                        </a>
                                    </div>
                                </div>
                              </div>


                            )
                        }
                    </div>
                </div>
            </>
        )
    }
}
