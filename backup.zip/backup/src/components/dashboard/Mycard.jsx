import React, { Component } from 'react'

export default class Mycard extends Component {
    constructor()
    {
        super();
        this.state={
            count:0
        }
    }

    decrement=()=>{
        this.setState({count:this.state.count-1})
    }
     incremnet=()=>{
        this.setState({count:this.state.count+1})
    }
  render() {
    return (
      <>
      {console.log("re-render")
      }
      <div style={{textAlign:"center"}}>
        <div>Mycard</div>
        <br />
        <div>{this.state.count}</div>
        <br />
        <br />
        <input type="submit" value="Decrememnt" onClick={this.decrement} />
        <input type="submit" value="Increment" onClick={this.incremnet} />
      </div>
      </>
    )
  }
}
