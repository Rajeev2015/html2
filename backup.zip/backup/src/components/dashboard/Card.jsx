import React, { Component } from 'react'
import "./dashbord.css"
export default class Card extends Component {
  constructor(props) {
    super(props)
    // console.log(this.props);

  }
  render() {
    return (
      <>
        <div className="card" style={{ width: "25%" }}>
          <img src={this.props.p_img} className="card-img-top my_img" alt="..." />
          <div className="card-body">
            <h5 className="card-title">{this.props.p_name}</h5>
            <h5 className="card-title">{this.props.p_price}</h5>
            <p className="card-text">
              {this.props.p_desc}
            </p>
            <a href="#" className="btn btn-primary">
              Go somewhere
            </a>
          </div>
        </div>

      </>
    )
  }
}
