import React, { Component } from 'react'
import Card from './Card'
import Mycard from './Mycard'
import CardDetails from './CardDetails'
import LiveData from './LiveData'

export default class Dashboard extends Component {
  render() {
    return (
      <>
        <div className='my_title'>Dashboard</div>
        <div style={{display:"flex"}}>
          <Card p_name="shirt" p_price="1200" p_desc="Very nice shirt" p_img="gallery/61.jpg" />
          <Card p_name="shirt" p_price="1000" p_desc="Very nice shirt" p_img="gallery/65.jpg" />
          <Card p_name="shirt" p_price="2000" p_desc="Very nice shirt" p_img="gallery/77.jpg" />
          <Card p_name="Tshirt" p_price="3200" p_desc="Very nice shirt" p_img="gallery/85.jpg" />
        </div>
        <br />
        <br />
        {/* <Mycard/> */}
        <CardDetails/>
        <br />
        <LiveData/>
      </>
    )
  }
}
