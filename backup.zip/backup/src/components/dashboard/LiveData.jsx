import axios from 'axios';
import React, { Component } from 'react'

export default class LiveData extends Component {
  constructor() {
    super();
    this.state = { mydata: [] }
  }
  getLiveDra = () => {
    axios.get("https://jsonplaceholder.typicode.com/posts")
      .then((res) => {
        // console.log(res);
        // console.log(res.data);
        // this.setState({mydata:res.data})
        if (res.status === 200 || res.status === 201 || res.status == "ok") {
          this.setState({ mydata: res.data })
        }


      })
  }
  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-md-12">
            <div className="my_title">live data</div>
          </div>
        </div>
        <div className="row">
          <div className="col-md-12">
            <div style={{ float: "right" }}>
              <input type="submit" className='btn btn-success' value="Get Live Data" onClick={this.getLiveDra} />
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-md-12">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>Id</th>
                  <th>User Id</th>
                  <th>Title</th>
                  <th>Boody</th>
                </tr>
              </thead>
              <tbody>
                {
                  this.state.mydata.map((v,i)=>
                    <tr>
                      <td>{v.id}</td>
                      <td>{v.userId}</td>
                      <td>{v.title}</td>
                      <td>{v.body}</td>
                    </tr>
                  )
                }
              </tbody>
            </table>
          </div>
        </div>
      </div>
    )
  }
}
