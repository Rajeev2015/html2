import axios from 'axios'
import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import Swal from 'sweetalert2';

export default class Contactlist extends Component {
    constructor() {
        super()
        this.state = { store: [] }
        console.log("I am from constructer");

    }
    // contactList = () => {

    // }
    componentDidMount() {
        console.log("I am from didamount");
        axios.get("http://localhost:3004/contact")
            .then((res) => {
                // console.log(res);
                this.setState({ store: res.data })

            })
    }

    deleteRecord = (id) => {
        // alert(id)
        // axios.delete("http://localhost:3004/contact/"+id)
        // .then((res)=>{
        //     // console.log(res);
        //     if(res.status===200)
        //     {
        //         this.componentDidMount()
        //     }

        // })

        Swal.fire({
            title: "Are you sure want to delete this " + id + " ?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!"
        }).then((result) => {
            if (result.isConfirmed) {

                axios.delete("http://localhost:3004/contact/" + id)
                    .then((res) => {
                        if (res.status === 200) {
                            Swal.fire({
                                title: "Deleted!",
                                text: "Your file has been deleted.",
                                icon: "success"
                            });
                            this.componentDidMount()
                        }
                    })
            }
        });
    }
    render() {
        { console.log("I am component Render") }
        return (
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <div className="my_title">
                            contact list
                        </div>
                    </div>
                </div>
                <div className="row">
                    {/* <div className="col-md-12">
                        <div style={{ float: "right" }}>
                            <input type="submit" value="Contact List" className='btn btn-danger' onClick={this.contactList} />
                        </div>
                    </div> */}
                    <div className="row">
                        <div className="col-md-12">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>First Name</th>
                                        <th>Last name</th>
                                        <th>Email id</th>
                                        <th>Mobile Number</th>
                                        <th>Message</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        this.state.store.map((item, index) =>
                                            <tr>
                                                <td>{item.id}</td>
                                                <td>{item.f_name}</td>
                                                <td>{item.l_name}</td>
                                                <td>{item.email_id}</td>
                                                <td>{item.mobile_number}</td>
                                                <td>{item.message}</td>
                                                <td>
                                                    <Link to="" className='btn btn-success'>Edit</Link>&nbsp;
                                                    <a href="#" className='btn btn-danger' onClick={() => { this.deleteRecord(item.id) }}>Delete</a>
                                                </td>
                                            </tr>
                                        )
                                    }
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
