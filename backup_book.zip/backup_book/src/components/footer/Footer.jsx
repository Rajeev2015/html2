import React from 'react'

export const Footer = () => {
  return (
   <footer className="text-white mt-5" style={{ backgroundColor: "#000" }}>
  <div className="container py-4">
    <div className="row">
      {/* About Section */}
      <div className="col-md-4">
        <h5 className="text-uppercase mb-3">Library Management</h5>
        <p>
          Manage your books efficiently with our digital library. Add, view, and
          update books seamlessly.
        </p>
      </div>
      {/* Quick Links */}
      <div className="col-md-4">
        <h5 className="text-uppercase mb-3">Quick Links</h5>
        <ul className="list-unstyled">
          <li>
            <a href="#" className="text-white text-decoration-none">
              Home
            </a>
          </li>
          <li>
            <a href="#" className="text-white text-decoration-none">
              Add Book
            </a>
          </li>
          <li>
            <a href="#" className="text-white text-decoration-none">
              View Books
            </a>
          </li>
          <li>
            <a href="#" className="text-white text-decoration-none">
              Contact
            </a>
          </li>
        </ul>
      </div>
      {/* Contact */}
      <div className="col-md-4">
        <h5 className="text-uppercase mb-3">Contact</h5>
        <p>Email: support@library.com</p>
        <p>Phone: +91 98765 43210</p>
        <p>Location: BBD University, Lucknow</p>
      </div>
    </div>
  </div>
  {/* Bottom */}
  <div className="text-center py-3" style={{ backgroundColor: "#111" }}>
    <small>© 2025 Book Library System | Designed by Rajeev Kumar</small>
  </div>
</footer>

  )
}
