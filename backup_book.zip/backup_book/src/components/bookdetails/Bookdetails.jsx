import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'


export const Bookdetails = () => {
    const [bookstore, setBookstore] = useState([])
    const _useNavigate=useNavigate()

    const getAllBookDetails = async () => {
        try {
            const book_data = await axios.get("http://localhost:3004/book_details");
            setBookstore(book_data.data)
            console.log(book_data);
            


        } catch (err) {
            console.log(err);

        }
    }

    const gotoBook=()=>{
        _useNavigate("/add-book")
    }
    useEffect(() => {
        getAllBookDetails();
    },[])
    return (
        <>
            {/* Make sure Font Awesome is included in your HTML head */}
            {/* Example: */}
            {/* <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" /> */}
           <div className="container mt-5">
      <h3 className="mb-4 text-center text-primary">
        <i className="fas fa-book me-2" /> Book List
      </h3>

      <div className="mb-3 text-end">
        <button className="btn btn-success">
          <i className="fas fa-plus me-2"> <input type="submit" className='btn btn-success' value="Add Book" onClick={gotoBook} /></i>
        </button>
      </div>

      <div className="table-responsive">
        <table className="table table-dark table-hover table-bordered align-middle text-center">
          <thead className="table-primary text-dark">
            <tr>
              <th>ID</th>
              <th>Book Name</th>
              <th>Author</th>
              <th>Edition</th>
              <th>Pages</th>
              <th>Price (₹)</th>
              <th>Description</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {bookstore.map((data, index) => (
              <tr key={index}>
                <td>{data.id}</td>
                <td>{data.book_name}</td>
                <td>{data.book_author}</td>
                <td>{data.book_edition}</td>
                <td>{data.book_page_number}</td>
                <td>{data.book_price}</td>
                <td>{data.book_descrition}</td>
                <td>
                  <button
                    className="btn btn-sm btn-warning me-2"
                   
                    title="Edit"
                  >
                    <i className="fas fa-edit"></i>
                  </button>
                  <button
                    className="btn btn-sm btn-danger"
                   
                    title="Delete"
                  >
                    <i className="fas fa-trash-alt"></i>
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
        </>

    )
}
