import axios from 'axios'
import React, { useState } from 'react'
import toast, { Toaster } from 'react-hot-toast';


export const Addbook = () => {
    const [bookdeatils, setBookdetails] = useState({
        book_name: '',
        book_author: '',
        book_edition: '',
        book_page_number: '',
        book_price: '',
        book_descrition: '',
    })
    const handleSubmit = async(e) => {
        e.preventDefault();
        // console.log(bookdeatils);
        try{
            const res=await axios.post("http://localhost:3004/book_details",bookdeatils)
            console.log(res);
            if(res.status===200 || res.status===201 || res.statusText==="ok")
            {
                toast.success("Book Added Successfully !")
            }
            
        }catch(err)
        {
            console.log(err);
            
        }
        


    }

    const handler = (e) => {
        // console.log(e);

        const { name, value } = e.target;  // object Destrcting
        // console.log(`name is ${name} and value is ${value}`);
        setBookdetails({ ...bookdeatils, [name]: value })

    }
    return (
        <div className="container mt-3 mb-3">
            <div className="row">
                <Toaster />
                <div className="col-md-3"></div>
                <div className="col-md-6">
                    <div className="card shadow p-4" style={{ borderRadius: "1rem" }}>
                        <h3 className="mb-4 text-center text-primary">Add Book Details</h3>
                        <form onSubmit={handleSubmit}>

                            <div className="mb-3">
                                <label htmlFor="book_name" className="form-label">
                                    Book Name
                                </label>
                                <input
                                    type="text"
                                    className="form-control"
                                    id="book_name"
                                    placeholder="Enter Book Name"
                                    required=""
                                    name='book_name'
                                    onChange={handler}
                                />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="book_author" className="form-label">
                                    Author Name
                                </label>
                                <input
                                    type="text"
                                    className="form-control"
                                    id="book_author"
                                    placeholder="Enter Author Name"
                                    required=""
                                    name='book_author'
                                    onChange={handler}
                                />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="book_edition" className="form-label">
                                    Edition
                                </label>
                                <input
                                    type="text"
                                    className="form-control"
                                    id="book_edition"
                                    placeholder="Enter Edition"
                                    required=""
                                    name='book_edition'
                                    onChange={handler}
                                />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="book_page_number" className="form-label">
                                    Total Page Number
                                </label>
                                <input
                                    type="number"
                                    className="form-control"
                                    id="book_page_number"
                                    placeholder="Enter Number of Pages"
                                    required=""
                                    name='book_page_number'
                                    onChange={handler}
                                />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="book_price" className="form-label">
                                    Price (₹)
                                </label>
                                <input
                                    type="number"
                                    className="form-control"
                                    id="book_price"
                                    placeholder="Enter Price"
                                    required=""
                                    name='book_price'
                                    onChange={handler}
                                />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="book_description" className="form-label">
                                    Description
                                </label>
                                <textarea
                                    className="form-control"
                                    id="book_description"
                                    rows={3}
                                    placeholder="Enter short description of the book"
                                    required=""
                                    defaultValue={""}
                                    name='book_descrition'
                                    onChange={handler}
                                />
                            </div>
                            <div className="text-center">
                                <button type="submit" className="btn btn-primary px-4">
                                    Add Book
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                <div className="col-md-3"></div>
            </div>
        </div>

    )
}
