import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import { Header } from './components/header/Header'
import { Footer } from './components/footer/Footer'
import { Dashboard } from './components/dashboard/Dashboard'
import { About } from './components/about/About'
import { Contact } from './components/contact/Contact'
import { Addbook } from './components/addbook/Addbook'
import { Pagenotfound } from './components/pagenotfound/Pagenotfound'
import { Bookdetails } from './components/bookdetails/Bookdetails'

function App() {
  

  return (
    <BrowserRouter>
      <Header/>
          <Routes>
            add-book
            <Route path="/" element={<Dashboard/>}/>
            <Route path="/about-us" element={<About/>}/>
            <Route path="/contact-us" element={<Contact/>}/>
            <Route path="/add-book" element={<Addbook/>}/>
            
            <Route path="/book-details" element={<Bookdetails/>}/>
            <Route path="*" element={<Pagenotfound/>}/>
          </Routes>
      <Footer/>
    </BrowserRouter>
  )
}

export default App
