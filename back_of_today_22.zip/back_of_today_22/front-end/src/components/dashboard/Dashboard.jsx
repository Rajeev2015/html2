import axios from 'axios';
import React, { useState } from 'react'



export const Dashboard = () => {
    const [state,setState]=useState(0);
    // console.log(useState(2));
    const [store,setStore]=useState([])

    const decrement=()=>{
        setState(state-1)

    }
     const increment=()=>{
        setState(state+1)
        
    }

    const getLiveData=async()=>{
        try{
                const response=await axios.get("https://jsonplaceholder.typicode.com/posts")
                // console.log(response);
                setStore(response.data)
                
        }catch(err)
        {
            console.log(err);
            
        }
    }
    
  return (
    <>
    {console.log('re-render')
    }
        <div style={{textAlign:"center"}}>
                <div>{`My value is ${state}`}</div>
                <br />
                <input type="submit" value="Decrement" className='btn btn-danger' onClick={decrement} />&nbsp;
                <input type="submit" value="Increment" className='btn btn-success' onClick={increment} />&nbsp;
                <br />
                <br />
                <input type="submit" value="Get live Data" onClick={getLiveData} className='btn btn-info' />
                <br />
                <br />
                <br />
                <ul>
                    {
                        store.map((v,i)=>
                            <li key={i}>{` Id is ${v.id}  user id id ${v.userId} and title is ${v.title} and body is ${v.body}`}</li>
                        )
                    }
                </ul>
        </div>
    </>
  )
}
