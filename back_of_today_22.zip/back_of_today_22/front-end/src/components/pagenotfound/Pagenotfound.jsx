import React from 'react'

export const Pagenotfound = () => {
  return (
    <div>Pagenotfound</div>
  )
}
