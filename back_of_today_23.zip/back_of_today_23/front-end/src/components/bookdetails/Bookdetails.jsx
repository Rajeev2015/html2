import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import Swal from 'sweetalert2'



export const Bookdetails = () => {
  const [bookstore, setBookstore] = useState([])
  const [bookdeatils, setBookdetails] = useState({
    book_name: '',
    book_author: '',
    book_edition: '',
    book_page_number: '',
    book_price: '',
    book_description: '',
  })
  const [status, setStatus] = useState(false)
  const _useNavigate = useNavigate()

  /* for searching pusrpose */
  const [searchText, setSearchText] = useState('');
  const [results, setResults] = useState([]);


  const getAllBookDetails = async () => {
    try {
      const book_data = await axios.get("http://localhost:4004/api/books");
      setBookstore(book_data.data)
      // console.log(book_data);



    } catch (err) {
      console.log(err);

    }
  }

  const handleDelete = async (id) => {
    try {
      Swal.fire({
        title: "Are you sure want to delete this " + id + " ?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!"
      }).then(async (result) => {
        if (result.isConfirmed) {

          const res = await axios.delete("http://localhost:4004/api/books/" + id)
          if (res.status === 200) {
            Swal.fire({
              title: "Deleted!",
              text: "Your file has been deleted.",
              icon: "success"
            });
            getAllBookDetails();
          }
        }
      });
    } catch (err) {
      console.log(err);

    }
  }

  // const searchById = async (e) => {
  //   const id = e.target.value;
  //   // alert(id)
  //   const res = await axios.get("http://localhost:3004/book_details/" + id)
  //   console.log(res);

  //   if (res.status === 200) {
  //     setBookdetails(res.data)
  //     setStatus(true)
  //   }




  // }

  const handleSearch = async (query) => {
    setSearchText(query); // keep input updated

    if (!query) {
      setResults([]);
      return;
    }

    try {
      const res = await axios.get(`http://localhost:4004/api/books/search/${query}`);
      // console.log(res.data.result);
      // console.log(res);
      if (res.status === 200) {
        setStatus(true)
        setResults(res.data.result)
      }



    } catch (err) {
      setResults([]);
      setErrorMsg('No books found.');
    }
  }

  const gotoBook = () => {
    _useNavigate("/add-book")
  }
  useEffect(() => {
    getAllBookDetails();
  }, [])
  return (
    <>
      <div className="container mt-5">
        <h3 className="mb-4 text-center text-primary">
          <i className="fas fa-book me-2" /> Book List
        </h3>
        <div className="mb-3" style={{ width: "30%" }}>

          {/* <select className="form-select" id="bookCategory" name='search_id' onChange={searchById}>
            <option value="">------ Select Id -----</option>
            {
              bookstore.map((v, i) =>
                <option value={v.id} key={i}>{v.id}</option>
              )
            }

          </select> */}
          <input
            type="text"
            placeholder="🔍 Search book by name"
            value={searchText}
            onChange={(e) => handleSearch(e.target.value)}
            onKeyUp={(e) => handleSearch(e.target.value)}
            className="form-control form-control-lg"
          />
        </div>


        <div className="mb-3 text-end">
          <button className="btn btn-success">
            <i className="fas fa-plus me-2"> <input type="submit" className='btn btn-success' value="Add Book" onClick={gotoBook} /></i>
          </button>
        </div>

        <div className="table-responsive">
          <table className="table table-dark table-hover table-bordered align-middle text-center">
            <thead className="table-primary text-dark">
              <tr>
                <th>ID</th>
                <th>Book Name</th>
                <th>Author</th>
                <th>Edition</th>
                <th>Pages</th>
                <th>Price (₹)</th>
                <th>Description</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {
                status ? (
                  <>
                    {
                      results.map((item, index) => {
                        return (
                          <tr key={index}>
                            <td>{index+1}</td>
                            <td>{item.book_name}</td>
                            <td>{item.book_author}</td>
                            <td>{item.book_edition}</td>
                            <td>{item.book_page_number}</td>
                            <td>{item.book_price}</td>
                            <td>{item.book_description}</td>
                            <td>
                              <Link to={`/edit/${item._id}`} style={{ color: "white" }}> <i className="bi bi-pencil-square"></i></Link>
                              &nbsp;&nbsp;&nbsp;&nbsp;
                              <a href="#" onClick={() => { handleDelete(item._id) }}><i className="bi bi-trash-fill" style={{ color: "red" }}></i></a>

                            </td>
                          </tr>
                        )
                      })
                    }

                  </>
                ) : (
                  <>
                    {bookstore.map((data, index) => (
                      <tr key={index}>
                        <td>{index + 1}</td>
                        <td>{data.book_name}</td>
                        <td>{data.book_author}</td>
                        <td>{data.book_edition}</td>
                        <td>{data.book_page_number}</td>
                        <td>{data.book_price}</td>
                        <td>{data.book_description}</td>
                        <td>
                          <Link to={`/edit/${data._id}`} style={{ color: "white" }}> <i className="bi bi-pencil-square"></i></Link>
                          &nbsp;&nbsp;&nbsp;&nbsp;
                          <a href="#" onClick={() => { handleDelete(data._id) }}> <img style={{ width: "20px", height: "20px", cursor: "pointer" }} src="src/assets/gallery/delete.png" alt="" /> </a>

                        </td>
                      </tr>
                    ))}
                  </>
                )

              }
            </tbody>
          </table>
        </div>
      </div>
    </>

  )
}
