import axios from 'axios'
import React, { useEffect, useState } from 'react'
const BASE_URL = import.meta.env.VITE_BASE_URL;

export const Dashboard = () => {
  const [cate, setCate] = useState([])
  const [blog, setBlog] = useState([])
  const [status,setStatus]=useState(false)

  const getAllCtegoery = async () => {
    try {
      const cateRes = await axios.get("http://localhost:4004/api/categories")
      console.log(cateRes);
      setCate(cateRes.data.categories)

    } catch (err) {
      console.log(err);

    }
  }

  const getAllBlogs = async () => {
    try {
      const blogRes = await axios.get("http://localhost:4004/api/blogs/all");
      console.log(blogRes);
      setBlog(blogRes.data.blogs)

    }
    catch (err) {
      console.log(err);

    }
  }

  const getDetailByCate=async(catename)=>{
    try{
        const resCategoery = await axios.get(`${BASE_URL}/api/blogs/category/${catename}`);
        console.log(resCategoery);
      
        if(resCategoery.status===200)
        {
          setBlog(resCategoery.data.blogs)
          if(resCategoery.data.blogs.length<=0)
          {
              setStatus(true)
          }
          else 
          {
            setStatus(false)
          }
        }
        
    }catch(err)
    {
      console.log(err);
      
    }
  }

  useEffect(() => {
    getAllCtegoery();
    getAllBlogs();
  }, [])
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-md-3">
          <div className="category-list-container p-3 rounded">
            <ul className="list-group list-group-flush">
              <li className="list-group-item active text-white bg-primary">
                📂 All Categories
              </li>
              {
                cate.map((c, i) =>
                  <li className="list-group-item" style={{ cursor: "pointer" }} onClick={()=>{getDetailByCate(c)}}>{c}</li>
                )
              }


            </ul>
          </div>

        </div>
        <div className="col-md-9">
          <div className="container-fluid" style={{marginTop:"2%"}}>
            {
              status?(
                <div className="row">
                  <div className="col-md-12">
                  <div className='alert alert-info'>Blog Not found</div>
                  </div>
                </div>
              ):(
                <div className="row">
              {
                blog.map((item, index) =>
                  <div className="col-md-4 p-1" key={index}>
                 
                    <div className="card shadow-lg rounded-4 border-0">
                       {/* <img src={`http://localhost:4004/uploads/${blog.images}`}
                                                className="card-img-top blog_img_width"
                                                alt={blog.blogtitle}
                                            /> */}
                      <img src={`${BASE_URL}/uploads/${item.images}`} className='dashbord_blog_image_height' />
                      <div className="card-body">
                        <h4 className="card-title fw-bold text-primary" style={{fontSize:"12px"}}>
                         {item.blogtitle.substring(0,30)}
                        </h4>
                        <p className="text-muted mb-1">
                          By <strong>{item.blogauthor}</strong> | {item.updatedAt}
                        </p>
                        <p className="card-text text-secondary mt-3">
                         {item.blogdescription.substring(0,60)}
                        </p>
                        <div className="d-flex justify-content-between align-items-center mt-4">
                          <span className="badge bg-darkblue text-light px-3 py-2 rounded-pill">
                            Web Development
                          </span>
                          <button className="btn btn-primary btn-sm rounded-pill px-4">
                            Read More
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                

                )
              }
            </div>
              )
            }
          </div>
        </div>
      </div>
    </div>
  )
}
