import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import { Header } from './components/header/Header'
import { Footer } from './components/footer/Footer'
import { Dashboard } from './components/dashboard/Dashboard'
import { Pagenotfound } from './components/pagenotfound/Pagenotfound'
import { About } from './components/about/About'
import { Contact } from './components/contact/Contact'
import { Register } from './components/register/Register'
import { Login } from './components/login/Login'
import { Addblog } from './components/addblog/Addblog'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
     <BrowserRouter>
          <Header/>
              <Routes>
                <Route path="/" element={<Dashboard/>}/>
                <Route path="/about-us" element={<About/>}/>
                <Route path="/contact-us" element={<Contact/>}/>
                <Route path="/sign-up" element={<Register/>}/>
                 <Route path="/login" element={<Login/>}/>
                 <Route path="/add-blog" element={<Addblog/>}/>
                <Route path="*" element={<Pagenotfound/>}/>
              </Routes>
          <Footer/>
     </BrowserRouter>
    </>
  )
}

export default App
