import axios from 'axios';
import React, { useEffect, useState } from 'react'
import toast, { Toaster } from 'react-hot-toast';



export const Addblog = () => {
    const [cate, setCate] = useState([])
    const [blog, setBlog] = useState({
        b_cate_name: '',
        b_title: '',
        b_author: '',
        b_desc: '',
        b_pic: null
    });

    const getAllCtegoery = async () => {
        try {
            const cateRes = await axios.get("http://localhost:4004/api/categories")
            // console.log(cateRes);
            setCate(cateRes.data.categories)

        } catch (err) {
            console.log(err);

        }
    }


    const handler = (e) => {
        const { name, value } = e.target;
        setBlog({ ...blog, [name]: value })

    }

    const uploadData = (e) => {
        // console.log(e.target.files);

        setBlog({ ...blog, b_pic: e.target.files[0] });   // <-- fixed setBlog

    }

    const handleBlogPost = async (e) => {
        e.preventDefault();
        try {
            
            const formData = new FormData();
            formData.append('b_cate_name', blog.b_cate_name);
            formData.append('b_title', blog.b_title);
            formData.append('b_author', blog.b_author);
            formData.append('b_desc', blog.b_desc);
            if (blog.b_pic) formData.append('images', blog.b_pic); // field = images
             const blogRes=await axios.post("http://localhost:4004/api/blogs/add",formData);
             console.log(blogRes);
             

        } catch (err) {

        }

    }

    useEffect(() => {
        getAllCtegoery()
    }, [])
    return (
        <>
            <Toaster />
            <div className="container my-5">
                <div className="row justify-content-center">
                    <div className="col-lg-6 col-md-8">

                        <form className="blog-form p-4 shadow-lg rounded-4 bg-white" onSubmit={handleBlogPost}>
                            <h3 className="mb-4 text-center fw-bold">Enter Blog</h3>
                            <div className="mb-3">
                                <label htmlFor="category" className="form-label fw-semibold">
                                    Select Category
                                </label>
                                <select name="b_cate_name" onChange={handler} id="" className='form-control'>
                                    <option value="">-------Select Categoery------</option>
                                    {
                                        cate.map((c, i) =>
                                            <option key={i} value={c}>{c}</option>
                                        )
                                    }
                                </select>

                            </div>

                            <div className="mb-3">
                                <label htmlFor="title" className="form-label fw-semibold">
                                    Blog Title
                                </label>
                                <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Enter Blog Title"
                                    name="b_title"
                                    onChange={handler}
                                />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="title" className="form-label fw-semibold">
                                    Author
                                </label>
                                <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Enter Blog Author "
                                    name="b_author"
                                    onChange={handler}
                                />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="b_desc" className="form-label fw-semibold">
                                    Enter Minimum 150 Characters
                                </label>
                                <textarea
                                    name="b_desc"
                                    placeholder="Enter Blog Description"
                                    className="form-control"

                                    required
                                    rows="6"
                                    onChange={handler}
                                ></textarea>
                            </div>

                            <div className="mb-3">
                                <label htmlFor="subtitle" className="form-label fw-semibold">
                                    Upload Blog Picture
                                </label>
                                <input
                                    type="file"
                                    className="form-control"
                                    onChange={uploadData}
                                />
                            </div>
                            <button type="submit" className="btn btn-primary w-10">
                                Publish Blog
                            </button>
                        </form>
                    </div>
                </div>
            </div>

        </>
    )
}
