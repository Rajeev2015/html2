import React from 'react'

export const Footer = () => {
  return (
  <footer className="bg-darkblue text-light pt-4 pb-3">
  <div className="container">
    <div className="row">
      {/* Column 1 */}
      <div className="col-md-4 mb-3">
        <h5>About Us</h5>
        <p>
          We offer full stack development training with real-world projects and expert guidance.
        </p>
      </div>

      {/* Column 2 */}
      <div className="col-md-4 mb-3">
        <h5>Quick Links</h5>
        <ul className="list-unstyled">
          <li><a href="#" className="text-light text-decoration-none">Home</a></li>
          <li><a href="#" className="text-light text-decoration-none">Courses</a></li>
          <li><a href="#" className="text-light text-decoration-none">Contact</a></li>
          <li><a href="#" className="text-light text-decoration-none">Blog</a></li>
        </ul>
      </div>

      {/* Column 3 */}
      <div className="col-md-4 mb-3">
        <h5>Contact Us</h5>
        <ul className="list-unstyled">
          <li>Email: info@example.com</li>
          <li>Phone: +91 9876543210</li>
          <li>Location: New Delhi, India</li>
        </ul>
      </div>
    </div>

    <div className="text-center mt-3">
      <small>&copy; 2025 Rajeev Kumar. All rights reserved.</small>
    </div>
  </div>
</footer>


  )
}
