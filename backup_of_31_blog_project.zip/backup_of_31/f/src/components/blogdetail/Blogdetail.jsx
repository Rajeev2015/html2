import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
const BASE_URL = import.meta.env.VITE_BASE_URL;
import toast, { Toaster } from 'react-hot-toast';
export const Blogdetail = () => {
    const [blog, setBlog] = useState(null)
    const { id } = useParams()
    const [comment, setComment] = useState()
    const [comments, setComments] = useState([]);

    const getBlogDetailById = async () => {
        try {
            const res = await axios.get(`${BASE_URL}/api/blogs/myblogs/detail/${id}`)
            console.log(res);
            setBlog(res.data.blog)


        } catch (err) {
            console.log(err);

        }
    }

 






    const handleCommentSubmit = async (e) => {
        e.preventDefault();
        // console.log(comment);
        if (!comment.trim()) {
            toast.error("Comment cannot be empty");
            return; // STOP execution here
        }
        try {
            const res = await axios.post(`${BASE_URL}/api/comments`, {
                commentText: comment.trim(),
                blog_id: id, // blog ID from URL
            });
            if (res.status === 201) {
                console.log(res);

                toast.success(res.data.message);
                setComment("");
            }

        } catch (err) {
            console.log(err);

        }

    }

       const getComments = async () => {
        try {

            const res = await axios.get(`${BASE_URL}/api/comments/${id}`);
            console.log(res);

            setComments(res.data.comments || []);
        } catch (err) {
            console.log("Failed to load comments", err);
        }
    };


  

    useEffect(() => {
        window.scrollTo(500, 0);
        getBlogDetailById()
        getComments()
    }, [id])

      //  If blog not loaded yet, show loading
    if (!blog) {
        return (
            <div className="container text-center py-5">
                <h4>⏳ Loading Blog Details...</h4>
            </div>
        );
    }
    return (
        <>
            <div className="container">
                <div className="row">

                    <div className="col-md-12">
                        <Toaster />
                        <div
                            style={{
                                margin: "2% 2%",
                                fontSize: "25px",
                                textTransform: "uppercase",
                                fontWeight: "bold",
                            }}
                        >
                            Blog Details
                        </div>
                    </div>
                </div>

                <div className="row">
                    <div className="col-md-8">
                        <div className="card mb-3 shadow rounded-4 p-3">
                            {blog.images && (
                                <img
                                    src={`${BASE_URL}/uploads/${blog.images}`}
                                    className="rounded-3 single_blog_img_height"
                                    alt="Blog Banner"
                                />
                            )}

                            <div className="card-body">
                                <h3 className="card-title fw-bold" style={{ textTransform: "capitalize" }}>
                                    {blog.blogtitle}
                                </h3>

                                <p className="card-text" style={{ textAlign: "justify" }}>
                                    {blog.blogdescription}
                                </p>

                                <h5 className="mt-4">🖋 Blog Author: {blog.blogauthor}</h5>
                                <p className="card-text">
                                    <small className="text-muted">
                                        📅 Last updated on{" "}
                                        {new Date(blog.updatedAt).toLocaleDateString()} at{" "}
                                        {new Date(blog.updatedAt).toLocaleTimeString()}
                                    </small>
                                </p>
                            </div>
                        </div>



                    </div>
                </div>
                <div className="row">
                    <div className="col-md-8">
                        <div className="card mt-4">
                            <div className="card-body">
                                <h5 className="card-title">💬 Leave a Comment</h5>
                                <form onSubmit={handleCommentSubmit}>
                                    <div className="mb-3">
                                        <textarea
                                            className="form-control"
                                            rows="3"
                                            value={comment}
                                            placeholder="Write your comment here..."
                                            onChange={(e) => setComment(e.target.value)}
                                        ></textarea>
                                    </div>
                                    <button type="submit" className="btn btn-primary">
                                        Submit Comment
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>


                {/* display all comments here  */}
                {/* 🗨️ Comment Count and Comment List */}
                <div className="card mt-4 shadow-sm">
                    <div className="card-body">
                        <h5 className="card-title">
                            🗨️ Comments ({comments.length})
                        </h5>

                        {comments.length === 0 ? (
                            <p className="text-muted">No comments yet. Be the first to comment!</p>
                        ) : (
                            <ul className="list-group list-group-flush">
                                {comments.map((cmt, index) => (
                                    <li key={index} className="list-group-item">
                                        <div>
                                            <p className="mb-1">{cmt.commentText}</p>
                                            <small className="text-muted">
                                                🕒 {new Date(cmt.createdAt).toLocaleString()}
                                            </small>
                                        </div>
                                    </li>
                                ))}
                            </ul>
                        )}
                    </div>
                </div>
            </div>


        </>
    )
}
